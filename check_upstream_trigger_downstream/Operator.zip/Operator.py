#!/usr/bin/env python3
#!coding: utf-8
from Hive_cmd import Hive_Cmd
import subprocess
import sys
import time
from Counting_down import COUNTING
from Down_stream import DOWN_STREAM
class Operator:
    def __init__(self,operator,database,tablename,date,**kwargs):
        self.operator = operator
        self.database = database
        self.tablename = tablename
        self.date = date
        self.encoding = 'utf-8'
    def check(self):
        hive_cmd_instance = Hive_Cmd(self.operator,self.database,self.tablename,self.date)
        hive_cmd_str = hive_cmd_instance()
        if self.operator == 'desc':
            num = 1
            while not isinstance(hive_cmd_str,int):
                print ("第{0}次重试...".format(num))
                COUNTING.counting_down()
                hive_cmd_instance = Hive_Cmd(self.operator, self.database, self.tablename, self.date)
                hive_cmd_str = hive_cmd_instance()
                num += 1
            print ('分区dt={0}文件数量获取成功'.format(self.date))
            print ('开始触发下游脚本...')
            try:
                DOWN_STREAM.run_job()
                print ("脚本执行完毕")
            except Exception as e:   #不走except,查原因
                print (e)
        if self.operator == 'select':
            num = 1
            while hive_cmd_str <= 0:
                print("第{0}次重试...".format(num))
                COUNTING.counting_down()
                hive_cmd_instance = Hive_Cmd(self.operator, self.database, self.tablename, self.date)
                hive_cmd_str = hive_cmd_instance()
                num += 1
            print("dt={0}的数据量大于0".format(sys.argv[4]))
            print('开始触发下游脚本...')
            try:
                DOWN_STREAM.run_job()
                print("脚本执行完毕")
            except Exception as e:  # 不走except,查原因
                print(e)


if __name__=='__main__':
    if sys.argv[1] == '-h':
        print ("参数用法:\n1.查询方法(select/desc)\n2.库名(app等)\n3.表名\n4.查询日期(如2017-12-31)\n5.重试等待间隔(分钟)\n6.下游脚本名称(带.py后缀)")
    else:
        operator = sys.argv[1]
        database = sys.argv[2]
        tablename = sys.argv[3]
        date = sys.argv[4]
        minute = sys.argv[5]
        downstream = sys.argv[6]
        a = Operator(operator=operator,database=database,tablename=tablename,date=date)
        a.check()

